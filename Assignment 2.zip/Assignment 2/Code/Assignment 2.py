#%%
import numpy as np
import pandas as pd
import pickle

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn import svm
from sklearn.metrics import accuracy_score


from astropy.table import Table, Column

# Load Sample Data

sample_data = pd.read_csv("E:\Semester 6\ML\Assignment 2\Heart Disease Prediction\Train-Test Split\Lecture 2\heart-disease-sample-data.csv")

print("\n\nSample Data:")
print("============\n")
pd.set_option("display.max_rows", None, "display.max_columns", None)
print(sample_data)

# Understand Sample Data

print("\n\nAttributes in Sample Data:")
print("==========================\n")

print(sample_data.columns)

print("\n\nNumber of Instances in Sample Data:",sample_data["sex"].count())
print("========================================\n")


sample_data_encoded_output = sample_data.copy()
original_sample_data = sample_data.copy()


# Labels

sex = pd.DataFrame({"sex":[0,1]})
fbs = pd.DataFrame({"Fbs":[0,1]})
restecg = pd.DataFrame({"restecg":[0,1]})
thal = pd.DataFrame({"thal":[1,2,3]})
target = pd.DataFrame({"target":[1,0]})

# Initialize the Label Encoders

sex_label_encoder = LabelEncoder()
fbs_label_encoder = LabelEncoder()
restecg_label_encoder = LabelEncoder()
thal_label_encoder = LabelEncoder()
target_label_encoder = LabelEncoder()

# Train the Label Encoders

sex_label_encoder.fit(np.ravel(sex))
fbs_label_encoder.fit(np.ravel(fbs))
restecg_label_encoder.fit(np.ravel(restecg))
thal_label_encoder.fit(np.ravel(thal))
target_label_encoder.fit(np.ravel(target))

# Transform Output of into Numerical Representation

print("\n\nSurvived Attribute After Label Encoding:")

print("========================================\n")
sample_data["encoded_survived"] = target_label_encoder.transform(sample_data['target'])
print(sample_data[["target", "encoded_survived"]])

# Print Original and Encoded Ouput Sample Data

sample_data_encoded_output[['sex', 'fbs', 'restecg', 'thal', 'target']] = sample_data[['sex', 'fbs', 'restecg', 'thal', 'target']]
pd.set_option("display.max_rows", None, "display.max_columns", None)
print("\n\nOriginal Sample Data:")
print("=====================\n")
pd.set_option("display.max_rows", None, "display.max_columns", None)
print(original_sample_data)
print("\n\nSample Data after Label Encoding of Output:")
print("===========================================\n")
pd.set_option("display.max_rows", None, "display.max_columns", None)
print(sample_data_encoded_output)

# Save the Transformed Features into CSV File

sample_data_encoded_output.to_csv(r'sample-data-encoded-output.csv', index = False, header = True)

print("\n\Sex Attribute After Label Encoding:")
print("======================================\n")
sample_data_encoded_output["encoded_sex"] = sex_label_encoder.transform(sample_data_encoded_output['sex'])
pd.set_option("display.max_rows", None, "display.max_columns", None)
print(sample_data_encoded_output[["sex", "encoded_sex"]])

print("\n\nfbs Attribute After Label Encoding:")
print("======================================\n")
sample_data_encoded_output["encoded_fbs"] = fbs_label_encoder.transform(sample_data_encoded_output['fbs'])
pd.set_option("display.max_rows", None, "display.max_columns", None)
print(sample_data_encoded_output[["fbs", "encoded_fbs"]])

print("\n\nrestecg Attribute After Label Encoding:")
print("=======================================\n")
sample_data_encoded_output["encoded_restecg"] = restecg_label_encoder.transform(sample_data_encoded_output['restecg'])
pd.set_option("display.max_rows", None, "display.max_columns", None)
print(sample_data_encoded_output[["restecg", "encoded_restecg"]])

print("\n\nthal Attribute After Label Encoding:")
print("========================================\n")
sample_data_encoded_output["encoded_thal"] = thal_label_encoder.transform(sample_data_encoded_output['thal'])
pd.set_option("display.max_rows", None, "display.max_columns", None)
print(sample_data_encoded_output[["thal", "encoded_thal"]])

# Print Original and Encoded Sample Data

sample_data_encoded[['sex', 'fbs', 'restecg', 'thal', 'target']] = sample_data_encoded_output[['sex', 'fbs', 'restecg', 'thal', 'target']]
print("\n\nOriginal Sample Data:")
print("=====================\n")
pd.set_option("display.max_rows", None, "display.max_columns", None)
print(original_sample_data)
print("\n\nSample Data after Label Encoding:")
print("=================================\n")
pd.set_option("display.max_rows", None, "display.max_columns", None)
print(sample_data_encoded)

# Save the Transformed Features into CSV File

sample_data_encoded.to_csv(r'sample-data-encoded.csv', index = False, header = True)

training_data_encoded, testing_data_encoded = train_test_split( sample_data_encoded , test_size=0.2 , random_state=0 , shuffle = False)

# Save the Training and Testing Data into CSV File

training_data_encoded.to_csv(r'training-data-encoded.csv', index = False, header = True)
testing_data_encoded.to_csv(r'testing-data-encoded.csv', index = False, header = True)

# print Training and Testing Data

print("\n\nTraining Data:")
print("==============\n")
pd.set_option("display.max_rows", None, "display.max_columns", None)
print(training_data_encoded)
print("\n\nTesting Data:")
print("==============\n")
pd.set_option("display.max_rows", None, "display.max_columns", None)
print(testing_data_encoded)


print("\n\nInputs Vectors (Feature Vectors) of Training Data:")
print("==================================================\n")
input_vector_train = training_data_encoded.iloc[: , :-1]
print(input_vector_train)

print("\n\nOutputs/Labels of Training Data:")
print("================================\n")
print("  Heart Disease Predicted")
output_label_train = training_data_encoded.iloc[: ,-1]
print(output_label_train)


# Train the Support Vector Classifier

print("\n\nTraining the Support Vector Classifier on Training Data")
print("========================================================\n")
print("\nParameters and their values:")
print("============================\n")
svc_model = svm.SVC(gamma='auto',random_state=0)
svc_model.fit(input_vector_train,np.ravel(output_label_train))
print(svc_model)


# Save the Model in a Pkl File

pickle.dump(svc_model, open('svc_trained_model.pkl', 'wb'))

print("\n\nInputs Vectors (Feature Vectors) of Testing Data:")
print("=================================================\n")
input_vector_test = testing_data_encoded.iloc[: , :-1]
print(input_vector_test)

print("\n\nOutputs/Labels of Testing Data:")
print("==============================\n")
print("  Heart Disease Predicted")
output_label_test = testing_data_encoded.iloc[: ,-1]
print(output_label_test)


# Load the Saved Model

model = pickle.load(open('svc_trained_model.pkl', 'rb'))


# Provide Test data to the Trained Model

model_predictions = model.predict(input_vector_test)

testing_data_encoded.copy(deep=True)
pd.options.mode.chained_assignment = None
testing_data_encoded["Predictions"] = model_predictions

# Save the Predictions into CSV File

testing_data_encoded.to_csv(r'Heart disease Prediction-Model.csv', index = False, header = True)

model_predictions = testing_data_encoded
print("\n\nPredictions Returned by svc_trained_model:")
print("==========================================\n")
print(model_predictions)


# Calculate the Accuracy

model_accuracy_score = accuracy_score(model_predictions["target"],model_predictions["Predictions"])

print("\n\nAccuracy Score:")
print("===============\n")
print(round(model_accuracy_score,2))
